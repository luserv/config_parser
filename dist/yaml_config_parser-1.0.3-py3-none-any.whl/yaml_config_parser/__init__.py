name = "yaml_config_parser"

from .yaml_config_parser import ConfigParser
